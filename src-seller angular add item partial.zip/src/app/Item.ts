export class Item{
    itemId : number;
    price : number;
    itemName : String;
    description : String;
    stockNumber : number;
    remarks : String;
    
}