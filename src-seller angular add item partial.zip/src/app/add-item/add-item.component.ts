import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor() { }

  item: Item=new Item();
  ngOnInit(): void {
  }

}
