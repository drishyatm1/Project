import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Seller } from './Seller';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  
  

  constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8085/seller/addSeller";
  addSeller(seller: Seller) : Observable<any> {
    console.log(seller);
    return this.http.post(`${this.baseUrl1}`,seller);
  }
}
