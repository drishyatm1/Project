package com.cts;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class EmployeeController {

	@RequestMapping(value="/AddEmployee.html" , method = RequestMethod. GET)
	public void getForm(Model m) {
		//Employee employee=new Employee();
		m.addAttribute(new Employee());
		//return "index";
		}
	
	@RequestMapping(value="/EmployeeDetails.html" , method = RequestMethod. POST)
	public void resultForm(@ModelAttribute Employee employee, Model m)
	{
		m.addAttribute("employee", employee);
		}
}
