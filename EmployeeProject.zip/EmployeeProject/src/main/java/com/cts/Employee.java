package com.cts;


public class Employee {
	
	
	private int employeeId;
	private String name;
	private String email;
	private long mobile;
	private String designation;
	private String address;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	public Employee() {
		
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String name, String email, long mobile, String designation, String address) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.designation = designation;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", email=" + email + ", mobile=" + mobile
				+ ", designation=" + designation + ", address=" + address + "]";
	}
	
	

}
