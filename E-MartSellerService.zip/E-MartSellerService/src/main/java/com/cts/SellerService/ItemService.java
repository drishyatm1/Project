package com.cts.SellerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SellerDao.IItemDao;
import com.cts.SellerDao.ISellerDao;
import com.cts.SellerModel.ItemEntity;
import com.cts.SellerModel.SellerEntity;


@Service
public class ItemService implements IItemService {
	
	@Autowired
	private IItemDao itemDao;
	
	@Autowired
	private ISellerDao sDao;

	@Override
	public String addItem(int sid, ItemEntity item) {
		SellerEntity i=sDao.getOne(sid);
		item.setSeller(i);
		System.out.println(item);
		itemDao.save(item);
		
		return "item added";
	}

	@Override
	public void deleteBySeller(Integer sId, Integer pId) {
		itemDao.deleteItem(sId,pId);
		
	}
	
	

}
