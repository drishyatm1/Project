package com.cts.SellerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SellerDao.ISellerDao;
import com.cts.SellerModel.SellerEntity;

@Service
public class SellerService implements ISellerService{

	
	@Autowired
	private ISellerDao sellerDao;
	
	@Override
	public List<SellerEntity> getAllSeller() {
		return sellerDao.findAll();
	}

	@Override
	public SellerEntity addSeller(SellerEntity seller) {
		return sellerDao.save(seller);
	}

}
