package com.cts.SellerService;

import com.cts.SellerModel.ItemEntity;

public interface IItemService {

	String addItem(int sid, ItemEntity item);

	void deleteBySeller(Integer sId, Integer pId);

}
