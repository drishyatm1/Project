package com.cts.SellerModel;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="item")
public class ItemEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int itemId;
	private float price;
	private String itemName;
	private String description;
	private int stockNumber;
	private String remarks;
	
	@ManyToOne
	private SubCategoryEntity subCategory;
	
	
	
	public SubCategoryEntity getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(SubCategoryEntity subCategory) {
		this.subCategory = subCategory;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public ItemEntity(int itemId, float price, String itemName, String description, int stockNumber, String remarks) {
		super();
		this.itemId = itemId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}
	public ItemEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ItemEntity [itemId=" + itemId + ", price=" + price + ", itemName=" + itemName + ", description="
				+ description + ", stockNumber=" + stockNumber + ", remarks=" + remarks + "]";
	}
	
	

	
	
	
	

}
