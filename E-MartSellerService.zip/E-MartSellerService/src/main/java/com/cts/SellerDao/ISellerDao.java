package com.cts.SellerDao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.SellerModel.SellerEntity;


@Repository
public interface ISellerDao extends JpaRepository<SellerEntity, Integer> {

}
