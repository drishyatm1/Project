package com.cts.SellerController;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SellerModel.ItemEntity;
import com.cts.SellerService.IItemService;




@RestController
public class ItemController {
	
	@Autowired
	private IItemService itemeService;
	
	
	@PostMapping("/addItem/BySellerId/{sid}")
	public String addItem(@PathVariable("sid") int sid, @RequestBody ItemEntity item) {
		
		return itemeService.addItem(sid,item);
	}
	
	@DeleteMapping("deleteById/{sid}/{pid}")
	public void deleteById(@PathVariable("sid") Integer sId, @PathVariable("pid") Integer pId) {
		
		itemeService.deleteBySeller(sId,pId);
		
	}
	
	@GetMapping(value = "viewItem/BySellerId/{sid}")
	public List<ItemEntity> viewItem(@PathVariable("sid")Integer sellerId) {
		return itemeService.viewItem(sellerId);
		}
	
	
	@PostMapping("/updateitem/{sid}/{pid}")
	public String updateItem(@PathVariable("sid") int sid,@PathVariable("pid") int pid,@RequestBody ItemEntity item)
	{
		return itemeService.updateItem(sid,pid,item);
	}

}
