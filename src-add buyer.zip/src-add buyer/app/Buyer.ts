export class Buyer{
  
    buyerUsername: String;
    buyerPassword: String;
    buyerEmailid: String;
    buyerMobile: number;
}