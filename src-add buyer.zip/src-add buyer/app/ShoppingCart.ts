export class ShoppingCart{
    cartId : Number;
    price : Number;
    quantity : number;

    itemId:number;

}