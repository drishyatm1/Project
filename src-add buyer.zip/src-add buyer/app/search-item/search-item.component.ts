import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { SearchItemServiceService } from '../search-item-service.service';
import { ShoppingCart } from '../ShoppingCart';
@Component({
  selector: 'app-search-item',
  templateUrl: './search-item.component.html',
  styleUrls: ['./search-item.component.css']
})
export class SearchItemComponent implements OnInit {
  itemNamePattern : String;
  item :Item[];
  //abc:any;
  item1:Item=new Item();
  cart: ShoppingCart= new ShoppingCart();
  
  constructor(private dataservice :SearchItemServiceService) { }

  ngOnInit(): void {
    this.itemNamePattern=""
    this.cart=new ShoppingCart();
  }

  onSubmit(){
    this.dataservice.getItemByName(this.itemNamePattern)
    .subscribe(item => this.item = item);
  }

  onSaveToCart(itemId: number,price:number){
    console.log(itemId);
    this.cart.itemId=itemId;
    this.cart.price=price;
    this.cart.quantity=1;
    this.dataservice.addToCart(this.cart).subscribe(cart => this.cart=cart);

  }
  
  

}
