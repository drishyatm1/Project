import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-after-login',
  templateUrl: './seller-after-login.component.html',
  styleUrls: ['./seller-after-login.component.css']
})
export class SellerAfterLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
