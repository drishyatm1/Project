import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Seller } from './Seller';
import { Observable } from 'rxjs';
import { Item } from './Item';

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  
  
  constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8085/seller/addSeller";
    addSeller(seller: Seller) : Observable<any> {
    console.log(seller);
    return this.http.post(`${this.baseUrl1}`,seller);
  }

  private baseUrl2="http://localhost:8085/item/addItem/BySellerId/100";
  addItem(item: Item,id:number) : Observable<any> {
    console.log(item);
    return this.http.post(`${this.baseUrl2}`,item);
  }

  private baseUrl3="http://localhost:8085/item/viewItem/BySellerId/100";
  viewItem() : Observable<any> {
    return this.http.get(`${this.baseUrl3}`);
  }

  private baseUrl4="http://localhost:8085/item/deleteById/104";
  deleteItem(sellerId: number, itemId: number) : Observable<any>  {
    return this.http.delete(`${this.baseUrl4}/${itemId}`);
  }

  private baseUrl5="http://localhost:8085/item/updateitem/104/10";
  updateItem(item: Item) :  Observable<any>{
    console.log(item);
    return this.http.post(`${this.baseUrl5}`,item);
  }
}
