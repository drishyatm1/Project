import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { SigninComponent } from './signin/signin.component';

import { SellerSignUpComponent } from './seller-sign-up/seller-sign-up.component';
import { AddItemComponent } from './add-item/add-item.component';
import { SellerViewItemComponent } from './seller-view-item/seller-view-item.component';
import { SellerAfterLoginComponent } from './seller-after-login/seller-after-login.component';



@NgModule({
  declarations: [
    AppComponent,
    MainMenuComponent,
    SigninComponent,
    SellerSignUpComponent,
    AddItemComponent,
    SellerViewItemComponent,
    SellerAfterLoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
