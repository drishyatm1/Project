export class Seller{
    username: String;
    password: String;
    companyName: String;
    gstin : number;
    companyDescription: String;
    postalAddress: String;
    website: String;
    emailID: String;
    contactNo: number;
    sellerId: number;

}