package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ItemsEntity {
	
	@Id
	public int itemId;
	public int categoryId;
	public int subcategoryId;
	public float price;
	public String itemName;
	public String description;
	public int stockNumber;
	public String remarks;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public ItemsEntity(int itemId, int categoryId, int subcategoryId, float price, String itemName, String description,
			int stockNumber, String remarks) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.subcategoryId = subcategoryId;
		this.price = price;
		this.itemName = itemName;
		this.description = description;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}
	public ItemsEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ItemsEntity [itemId=" + itemId + ", categoryId=" + categoryId + ", subcategoryId=" + subcategoryId
				+ ", price=" + price + ", itemName=" + itemName + ", description=" + description + ", stockNumber="
				+ stockNumber + ", remarks=" + remarks + "]";
	}


	
	
}
