package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class SubCategoryEntity {

	@Id
	public int subcategoryId;
	public String subcategoryName;
	public int CategoryId;
	public String briefDetails;
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public int getCategoryId() {
		return CategoryId;
	}
	public void setCategoryId(int categoryId) {
		CategoryId = categoryId;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public SubCategoryEntity(int subcategoryId, String subcategoryName, int categoryId, String briefDetails) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		CategoryId = categoryId;
		this.briefDetails = briefDetails;
	}
	public SubCategoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SubCategoryEntity [subcategoryId=" + subcategoryId + ", subcategoryName=" + subcategoryName
				+ ", CategoryId=" + CategoryId + ", briefDetails=" + briefDetails + "]";
	}

	
	
}
