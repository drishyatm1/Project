package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class BuyerEntity {

	@Id
	private int buyerId;
	private String buyerUsername;
	private String buyerPassword;
	private String buyerEmailid;
	private long buyerMobile;
	private String createdDatetime;
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public String getBuyerUsername() {
		return buyerUsername;
	}
	public void setBuyerUsername(String buyerUsername) {
		this.buyerUsername = buyerUsername;
	}
	public String getBuyerPassword() {
		return buyerPassword;
	}
	public void setBuyerPassword(String buyerPassword) {
		this.buyerPassword = buyerPassword;
	}
	public String getBuyerEmailid() {
		return buyerEmailid;
	}
	public void setBuyerEmailid(String buyerEmailid) {
		this.buyerEmailid = buyerEmailid;
	}
	public long getBuyerMobile() {
		return buyerMobile;
	}
	public void setBuyerMobile(long buyerMobile) {
		this.buyerMobile = buyerMobile;
	}
	public String getCreatedDatetime() {
		return createdDatetime;
	}
	public void setCreatedDatetime(String createdDatetime) {
		this.createdDatetime = createdDatetime;
	}
	public BuyerEntity(int buyerId, String buyerUsername, String buyerPassword, String buyerEmailid, long buyerMobile,
			String createdDatetime) {
		super();
		this.buyerId = buyerId;
		this.buyerUsername = buyerUsername;
		this.buyerPassword = buyerPassword;
		this.buyerEmailid = buyerEmailid;
		this.buyerMobile = buyerMobile;
		this.createdDatetime = createdDatetime;
	}
	public BuyerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "BuyerEntity [buyerId=" + buyerId + ", buyerUsername=" + buyerUsername + ", buyerPassword="
				+ buyerPassword + ", buyerEmailid=" + buyerEmailid + ", buyerMobile=" + buyerMobile
				+ ", createdDatetime=" + createdDatetime + "]";
	}
	
	

}
