package com.cts.entity;

import javax.persistence.Entity;

@Entity
public class PurchaseHistoryEntity {

}
