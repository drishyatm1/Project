package com.cts.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PurchaseHistoryEntity {
	
	@Id
	public int purchaseHistoryId;
	public int buyerId;
	public int sellerId;
	public int transactionId;
	public int itemId;
	public int numberOfItems;
	
	public String remarks;

	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public PurchaseHistoryEntity(int purchaseHistoryId, int buyerId, int sellerId, int transactionId, int itemId,
			int numberOfItems, String remarks) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyerId = buyerId;
		this.sellerId = sellerId;
		this.transactionId = transactionId;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.remarks = remarks;
	}

	public PurchaseHistoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchaseHistoryId=" + purchaseHistoryId + ", buyerId=" + buyerId + ", sellerId="
				+ sellerId + ", transactionId=" + transactionId + ", itemId=" + itemId + ", numberOfItems="
				+ numberOfItems + ", remarks=" + remarks + "]";
	}

	

}
