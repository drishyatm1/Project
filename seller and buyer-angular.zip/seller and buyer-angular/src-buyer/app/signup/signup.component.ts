import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { SearchItemServiceService } from '../search-item-service.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  
  constructor(private buyerservice:SearchItemServiceService,private router: Router) { }
  buyer:Buyer =new Buyer();
  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    console.log(this.buyer);
    this.buyerservice.createbuyer(this.buyer)
    .subscribe(buyer=>{alert("your details are saved successfully .")})
    this.router.navigate(['SignIn']);

  }
}
