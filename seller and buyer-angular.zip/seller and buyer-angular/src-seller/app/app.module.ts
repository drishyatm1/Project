import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppComponent } from './app.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { SigninComponent } from './signin/signin.component';

import { SellerSignUpComponent } from './seller-sign-up/seller-sign-up.component';
import { AddItemComponent } from './add-item/add-item.component';
import { SellerViewItemComponent } from './seller-view-item/seller-view-item.component';
import { SellerAfterLoginComponent } from './seller-after-login/seller-after-login.component';
import { LogoutComponent } from './logout/logout.component';
import { SellerServiceService } from './seller-service.service';
import { TokenInterceptor } from './interceptor';



@NgModule({
  declarations: [
    AppComponent,
    MainMenuComponent,
    SigninComponent,
    SellerSignUpComponent,
    AddItemComponent,
    SellerViewItemComponent,
    SellerAfterLoginComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
