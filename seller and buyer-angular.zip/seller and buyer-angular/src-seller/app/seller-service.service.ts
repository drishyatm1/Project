import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Seller } from './Seller';
import { Observable } from 'rxjs';
import { Item } from './Item';
import { ApiResponse } from './api.response';

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  
  constructor(private http:HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8085/' + 'token/generate-token', loginPayload);
  }
  
   private baseUrl1="http://localhost:8085/seller/addSeller";
    addSeller(seller: Seller) : Observable<any> {
    console.log(seller);
    return this.http.post(`${this.baseUrl1}`,seller);
  }

  private baseUrl2="http://localhost:8085/item/addItem/BySellerId";
  addItem(item: Item,id:String) : Observable<any> {
    console.log(item);
    return this.http.post(`${this.baseUrl2}/${id}`,item);
  }

  private baseUrl3="http://localhost:8085/item/viewItem/BySellerId";
  viewItem(sid:String) : Observable<any> {
    return this.http.get(`${this.baseUrl3}/${sid}`);
  }

  private baseUrl4="http://localhost:8085/item/deleteById";
  deleteItem(sid: String, itemId: number) : Observable<any>  {
    return this.http.delete(`${this.baseUrl4}/${sid}/${itemId}`);
  }

  private baseUrl5="http://localhost:8085/item/updateitem";
  updateItem1(iId:number,item: Item,sid:String) :  Observable<any>{
    console.log(item);
    return this.http.post(`${this.baseUrl5}/${sid}/${iId}`,item);
  }
}
