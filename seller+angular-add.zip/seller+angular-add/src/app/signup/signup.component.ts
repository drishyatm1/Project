import { Component, OnInit } from '@angular/core';
import { Seller } from '../Seller';
import { SellerServiceService } from '../seller-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private sellerservice:SellerServiceService,private router: Router) { }
  seller:Seller =new Seller();
  ngOnInit(): void {
  }

  onSubmit(form){

    console.log(this.seller);
    this.sellerservice.createSeller(this.seller)
    .subscribe(seller=>{alert("your details are saved successfully .")})
    this.router.navigate(['signin']);

  }

}
