export class Seller{
    username: String;
    password: String;
    companyName: String;
    GSTIN : number;
    companyDescription: String;
    PostalAddress: String;
    website: String;
    emailID: String;
    contactNo: number;


}