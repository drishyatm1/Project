package com.cts.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="purchase_history")
public class PurchaseHistoryEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	public int purchaseHistoryId;
	public int numberOfItems;
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="date_time")
	public Date DateTime;
	

	
	@ManyToOne
	private BuyerEntity buyer;
	
	
	
	public BuyerEntity getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerEntity buyer) {
		this.buyer = buyer;
	}
	
	

	public Date getDateTime() {
		return DateTime;
	}

	public void setDateTime(Date dateTime) {
		this.DateTime = dateTime;
	}

	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	



	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	

	

	

	

	public PurchaseHistoryEntity(int purchaseHistoryId, int numberOfItems, Date dateTime, BuyerEntity buyer) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.numberOfItems = numberOfItems;
		this.DateTime = dateTime;
		this.buyer = buyer;
	}

	public PurchaseHistoryEntity() {
		super();
		System.out.println("obj created");
	}

	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchaseHistoryId=" + purchaseHistoryId + ", numberOfItems=" + numberOfItems
				+ ", DateTime=" + DateTime + ", buyer=" + buyer + "]";
	}

	

	

	

	

	

}
