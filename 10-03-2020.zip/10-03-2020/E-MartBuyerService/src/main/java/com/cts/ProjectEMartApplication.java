package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectEMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectEMartApplication.class, args);
	}

}
