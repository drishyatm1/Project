package com.egg.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.ISellerDao;
import com.egg.model.SellerEntity;
import com.egg.service.ISellerService;

@Service
public class SellerService implements ISellerService{

	
	@Autowired
	private ISellerDao sellerDao;
	
	@Override
	public List<SellerEntity> getAllSeller() {
		return sellerDao.findAll();
	}

	@Override
	public SellerEntity addSeller(SellerEntity seller) {
		System.out.println(seller);
		return sellerDao.save(seller);
	}

}
