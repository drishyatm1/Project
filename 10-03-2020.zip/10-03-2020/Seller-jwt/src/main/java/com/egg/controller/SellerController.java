package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.SellerEntity;
import com.egg.service.ISellerService;




@RestController
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private ISellerService sellerService; 
	
	@GetMapping("/getAllSeller")
	public List<SellerEntity> getAll(){
		
		return sellerService.getAllSeller();
	}
	
	@PostMapping(value="/addSeller")
	public SellerEntity addSeller(@RequestBody SellerEntity seller) {
		
		return sellerService.addSeller(seller);
	}

}
