package com.egg.service;

import java.util.List;

import com.egg.model.SellerEntity;

public interface ISellerService {

	List<SellerEntity> getAllSeller();

	SellerEntity addSeller(SellerEntity seller);

	SellerEntity findOne(String username);

}
