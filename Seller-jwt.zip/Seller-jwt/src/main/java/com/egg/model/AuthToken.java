package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
    private int sellerId;
    public AuthToken(){

    }
	public AuthToken(String token, String username, int sellerId) {
		super();
		this.token = token;
		this.username = username;
		this.sellerId = sellerId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

   
}
