package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.CategoryEntity;
import com.egg.service.ICategoryService;


@RestController
public class CategoryController {

	@Autowired
	private ICategoryService catService;
	
	@GetMapping("/getAllCategory")
	public List<CategoryEntity> getAll(){
		
		return catService.getAllCategory();
	}
}
