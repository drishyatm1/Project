package com.egg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.SubCategoryEntity;
import com.egg.service.ISubCategoryService;


@RestController
public class SubCategoryController {

	@Autowired
	private ISubCategoryService subcatService;
	
	@GetMapping("/getAllSubCategory")
	public List<SubCategoryEntity> getAllSubCategory(){
		
		return subcatService.getAllSubCategory();
	}
}
