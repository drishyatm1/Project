package com.egg.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.IItemDao;
import com.egg.dao.ISellerDao;
import com.egg.model.ItemEntity;
import com.egg.model.SellerEntity;
import com.egg.service.IItemService;



@Service
public class ItemService implements IItemService {
	
	@Autowired
	private IItemDao itemDao;
	
	@Autowired
	private ISellerDao sDao;

	@Override
	public String addItem(int sid, ItemEntity item) {
		SellerEntity i=sDao.getOne(sid);
		item.setSeller(i);
		System.out.println(item);
		itemDao.save(item);
		
		return "item added";
	}

	@Override
	public void deleteBySeller(Integer sId, Integer pId) {
		itemDao.deleteItem(sId,pId);
		
	}

	@Override
	public List<ItemEntity> viewItem(Integer sellerId) {
		return itemDao.viewItem(sellerId);
		
	}

	@Override
	public String updateItem(int sid, int pid, ItemEntity item) {
		
		ItemEntity updateItem1=itemDao.getItemBy(sid,pid);
		System.out.println(updateItem1);
		//System.out.println(item);
		float price1=item.getPrice();
		int stockNumber1=item.getStockNumber();
		updateItem1.setPrice(price1);
		updateItem1.setStockNumber(stockNumber1);
		System.out.println(updateItem1);

		itemDao.save(updateItem1);
				return "updated";
	}

	@Override
	public List<ItemEntity> getMatchingItem(String name) {
		
		return itemDao.getMatchingItem(name);
	}

	
	
	
	
	

}
