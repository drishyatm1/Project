package com.egg.service;

import java.util.List;
import java.util.Optional;

import com.egg.model.BuyerEntity;
import com.egg.model.ShoppingCartEntity;

public interface IBuyerService {

	List<BuyerEntity> getAllPersons();

	BuyerEntity add(BuyerEntity buyer);

	BuyerEntity findOne(String username);

	//Optional<ShoppingCartEntity> getbyBuyerId(int pid);
	
	

}
