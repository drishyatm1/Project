package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.ShoppingCartEntity;

public interface ICartService {

	List<ShoppingCartEntity> getAllCart();

	//Optional<ShoppingCartEntity> getbyBuyerId(int pid);

}
