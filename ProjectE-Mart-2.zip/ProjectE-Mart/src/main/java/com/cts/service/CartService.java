package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ICartDao;
import com.cts.model.ShoppingCartEntity;

@Service
public class CartService implements ICartService {
	
	@Autowired
	private ICartDao cartDao;

	@Override
	public List<ShoppingCartEntity> getAllCart() {
		
		return cartDao.findAll();
	}

	
}
