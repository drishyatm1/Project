package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;
import com.cts.service.ICartService;


@RestController
public class CartController {
	@Autowired
	private ICartService cartService;
	
	@GetMapping("/getAll/CartItem")
	public List<ShoppingCartEntity> getAll(){
		
		return cartService.getAllCart();
	}
	
	/*
	 * @RequestMapping("getCartItem/ByBuyerId/{eid}") public ShoppingCartEntity
	 * getbyBuyerId(@PathVariable("eid") int pid) {
	 * 
	 * Optional<ShoppingCartEntity> p=cartService.getbyBuyerId(pid);
	 * ShoppingCartEntity pObj=null; if(p.isPresent()){ pObj=p.get(); } return pObj;
	 * }
	 */

}
