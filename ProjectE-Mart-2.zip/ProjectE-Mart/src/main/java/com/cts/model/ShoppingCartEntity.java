package com.cts.model;

import java.util.List;

import javax.persistence.*;


@Entity
@Table(name="cart")
public class ShoppingCartEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int cartId;
	private float price;
	private String description;
	
	
	 
	
	  @OneToMany//(cascade=CascadeType.ALL,mappedBy="shoppingCart")
	  private List<ItemsEntity> itemsEntity;
	    
	  @ManyToOne
	  private BuyerEntity buyer;
	 
	 
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public ShoppingCartEntity() {
		
		// TODO Auto-generated constructor stub
	}
	public ShoppingCartEntity(int cartId, float price, String description) {
		super();
		this.cartId = cartId;
		this.price = price;
		this.description = description;
	}
	@Override
	public String toString() {
		return "ShoppingCartEntity [cartId=" + cartId + ", price=" + price + ", description=" + description + "]";
	}
	
	
	
	
	
	

}
