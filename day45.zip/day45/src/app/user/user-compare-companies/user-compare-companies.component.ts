import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-compare-companies',
  templateUrl: './user-compare-companies.component.html',
  styleUrls: ['./user-compare-companies.component.css']
})
export class UserCompareCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
