import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-company-sectors',
  templateUrl: './user-company-sectors.component.html',
  styleUrls: ['./user-company-sectors.component.css']
})
export class UserCompanySectorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
