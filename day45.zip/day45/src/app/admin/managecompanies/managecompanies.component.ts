import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managecompanies',
  templateUrl: './managecompanies.component.html',
  styleUrls: ['./managecompanies.component.css']
})
export class ManagecompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
