export class Company{
    id:number;
    companyname:string;
    city:string;
    turnover:number;
    ceo:string;

}