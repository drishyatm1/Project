export class exchange{
    id:number;
    exchangeName:String;
    contactAddress:String;
    brief:String;
    remarks:String;
}