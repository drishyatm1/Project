export class User{
    id:number;
    name:string;
    email:string;
    phone:number;
    username:string;
    password:string;

}