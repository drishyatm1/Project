import {User} from './user';
export const USERS : User[]=[
    {id:101,name:'Aniket',email:'aniket@gmail.com',phone :6677,username:'101',password:'password'},
    {id:102,name:'juli',email:'juli@gmail.com',phone:488, username:'102',password:'password'},
    {id:103,name:'mili',email:'mili@gmail.com',phone:4000,username:'103',password:'password'},
    {id:104,name:'sindhu',email:'sindhu@gmail.com',phone:3456,username:'106',password:'password'},
    {id:105,name:'sairam',email:'sairam@gmail.com',phone:3566,username:'105',password:'password'},

];