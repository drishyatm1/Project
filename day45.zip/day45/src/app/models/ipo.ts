export class Ipo{
    id:number;
    companyName:String;
    stockExchange:String;
    pricePerShare:number;
    noOfShares:number;
    openDateTime:Date;
    remarks:String;
}