import {Company} from './company';
export const COMPANIES : Company[]=[

    {id:1,companyname:'cts',city:'chennai',turnover:14,ceo:'ABC'},
    {id:2,companyname:'tcs',city:'kochi',turnover:16,ceo:'XYZ'},
];