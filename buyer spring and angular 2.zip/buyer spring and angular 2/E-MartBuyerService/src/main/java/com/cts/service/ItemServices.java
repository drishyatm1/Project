package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.IItemDao;
import com.cts.model.ItemsEntity;

@Service
public class ItemServices implements IItemService {

	
	@Autowired
	private IItemDao itemsDao;
	
	@Override
	public List<ItemsEntity> getMatchingItem(String name) {
		return itemsDao.getMatchingItem(name);
	}

}
