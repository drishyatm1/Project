import { Component, OnInit } from '@angular/core';
import { ShoppingCart } from '../ShoppingCart';
import { SearchItemServiceService } from '../search-item-service.service';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {


  displayCart: ShoppingCart[];
  cart: ShoppingCart= new ShoppingCart();
  count: number;

  constructor(private display :SearchItemServiceService) { }

  ngOnInit(): void {
    this.display.displayCartItems()
    .subscribe(displayCart => this.displayCart= displayCart)
    console.log(this.displayCart)
  }
  decrease(cart:ShoppingCart,id: number){
    
    cart.quantity -=1;
    this.display.updateCart(this.cart).subscribe(cart => this.cart=cart);
    console.log(cart.quantity);
  }

  increase(cart:ShoppingCart,id: number){
    console.log(cart.quantity)
    console.log(cart);
    cart.quantity +=1;
    this.display.updateCart(this.cart).subscribe(cart => this.cart=cart);
    console.log(cart.quantity);
  }

  delete(id: number){

    this.display.deleteCartItem(id)
    .subscribe(()=>console.log("deleted"));
  }
}
