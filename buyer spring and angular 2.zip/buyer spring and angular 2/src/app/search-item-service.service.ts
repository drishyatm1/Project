import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart'
import { Buyer } from './Buyer';
@Injectable({
  providedIn: 'root'
})
export class SearchItemServiceService {
  
 
  
  constructor(private http:HttpClient) { }

  private baseUrl1="http://localhost:8085/item/getMatchingItem";
  getItemByName(itemNamePattern : String) : Observable<any> {
    return this.http.get(`${this.baseUrl1}/${itemNamePattern}`);
  }
 
  private baseUrl2="http://localhost:8080/cart";
  addToCart(cart: ShoppingCart) : Observable<any> {
    return this.http.post(`${this.baseUrl2}/`+`addToCart/ById/100`,cart);
  }


  private baseUrl3="http://localhost:8080/cart/getAll/CartItem";
  displayCartItems() : Observable<any>{
    return this.http.get(`${this.baseUrl3}`);
  }


  private baseUrl4="http://localhost:8080/buyer/addBuyer";
  createbuyer(buyer: Buyer) :  Observable<any> {
    return this.http.post(`${this.baseUrl4}`,buyer);
  }

  private baseUrl5="http://localhost:8080/cart/updatecart/205";
  updateCart(cart: ShoppingCart) :  Observable<any>{
    console.log(cart);
    return this.http.post(`${this.baseUrl5}`,cart);
    
  }
  

  private baseUrl6="http://localhost:8080/cart/deleteById/206";
  deleteCartItem(id: any) :  Observable<any>{
    return this.http.delete(`${this.baseUrl6}`);
  }
  
 
  
}

