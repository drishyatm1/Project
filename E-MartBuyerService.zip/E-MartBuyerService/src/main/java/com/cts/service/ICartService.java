package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.ShoppingCartEntity;

public interface ICartService {

	List<ShoppingCartEntity> getAllCart();

	Optional<ShoppingCartEntity> getCartById(int bid);

	

	void deleteById(Integer bId);

	//void deleteAllCart();

	String addCart(int bid, ShoppingCartEntity cItem);
	String updateCart(int cid, ShoppingCartEntity sCart);
	void emptyCart(Integer buyerId);

	List<ShoppingCartEntity> getAllCartItems(Integer buyerId);
	

	

	

	

//	String addCart(int bid, ShoppingCartEntity scart);

	

	

}
