package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.IBuyerDao;
import com.cts.dao.ICartDao;
import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;

@Service
public class CartService implements ICartService {

	@Autowired
	private ICartDao cartDao;
	@Autowired
	private IBuyerDao bdao;

	@Override
	public List<ShoppingCartEntity> getAllCart() {

		return cartDao.findAll();
	}

	@Override
	public Optional<ShoppingCartEntity> getCartById(int bid) {
		// TODO Auto-generated method stub
		return cartDao.findById(bid);
	}

	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCartEntity> buyer = cartDao.findById(bId);

		if (buyer.isPresent()) {
			cartDao.deleteById(bId);
		}

	}

	@Override
	public void deleteAllCart() {
		cartDao.deleteAll();

	}

	@Override
	public String addCart(int bid, ShoppingCartEntity cItem) {
		BuyerEntity br = bdao.getOne(bid);
		cItem.setBuyer(br);
		// TODO Auto-generated method stub
		System.out.println(cItem);
		cartDao.save(cItem);
		return "item added";

	}

	@Override
	public ShoppingCartEntity update(ShoppingCartEntity cartItem) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateCart(int cid, ShoppingCartEntity sCart) {

		ShoppingCartEntity cartUpdate = cartDao.getOne(cid);

		// int prid=sCart.getProductid(); to be added
		float price = sCart.getPrice();
		String description = sCart.getDescription();
		int quantity = sCart.getQuantity();

		cartUpdate.setQuantity(quantity);

		System.out.println(cartUpdate);
		cartDao.save(cartUpdate);
		return "\"Cart item updated\"";
	}

	@Override
	public void emptyCart(Integer buyerId) {
		cartDao.emptyCart(buyerId);

	}

}
