package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.IBuyerDao;
import com.cts.dao.ICartDao;
import com.cts.dao.IItemDao;
import com.cts.dao.IPurchaseHistoryDao;
import com.cts.dao.ITransactionDao;
import com.cts.model.BuyerEntity;
import com.cts.model.ItemsEntity;
import com.cts.model.PurchaseHistoryEntity;
import com.cts.model.ShoppingCartEntity;
import com.cts.model.TransactionEntity;

@Service
public class CartService implements ICartService {

	@Autowired
	private ICartDao cartDao;
	@Autowired
	private IBuyerDao bdao;

	@Autowired
	private IItemDao itemDao;
	
	@Autowired
	private ITransactionDao transactionDao;
	
	@Autowired
	private IPurchaseHistoryDao purchaseDao;
	
	@Override
	public List<ShoppingCartEntity> getAllCart() {

		return cartDao.findAll();
	}

	@Override
	public Optional<ShoppingCartEntity> getCartById(int bid) {
		// TODO Auto-generated method stub
		return cartDao.findById(bid);
	}

	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCartEntity> buyer = cartDao.findById(bId);

		if (buyer.isPresent()) {
			cartDao.deleteById(bId);
		}

	}

	@Override
	public String addCart(int bid, ShoppingCartEntity cItem) {
		BuyerEntity br = bdao.getOne(bid);
		cItem.setBuyer(br);
		// TODO Auto-generated method stub
		System.out.println(cItem);
		cartDao.save(cItem);
		return "item added";

	}

	
	@Override
	public String updateCart(int cid, ShoppingCartEntity sCart) {
		ShoppingCartEntity cartUpdate = cartDao.getOne(cid);
		int quantity = sCart.getQuantity();
		cartUpdate.setQuantity(quantity);
		System.out.println(cartUpdate);
		cartDao.save(cartUpdate);
		return "\"Cart item updated\"";
	}

	@Override
	public void emptyCart(Integer buyerId) {
		cartDao.emptyCart(buyerId);

	}

	@Override
	public List<ShoppingCartEntity> getAllCartItems(Integer buyerId) {
		return cartDao.getAllCartItems(buyerId);
	}

	@Override
	public String checkOut(TransactionEntity transaction, int buyerid) {
		BuyerEntity buyer=bdao.getOne(buyerid);
		System.out.println(buyer);
		transaction.setBuyer(buyer);
		System.out.println(transaction);
		transactionDao.save(transaction);
		
		List<ShoppingCartEntity> sCart=cartDao.getById(buyerid);
		for(int i=0;i<sCart.size();i++)
		{	
			PurchaseHistoryEntity pHistory=new PurchaseHistoryEntity();
			ShoppingCartEntity scItem=sCart.get(i);
			int noOfItem=scItem.getQuantity();
			pHistory.setNumberOfItems(noOfItem);
			pHistory.setBuyer(buyer);
			System.out.println(scItem);
			purchaseDao.save(pHistory);
		}
		
		return null;
	}

	
	

	

}
