package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;

public interface IBuyerService {

	List<BuyerEntity> getAllPersons();

	BuyerEntity add(BuyerEntity buyer);

	//Optional<ShoppingCartEntity> getbyBuyerId(int pid);
	
	

}
