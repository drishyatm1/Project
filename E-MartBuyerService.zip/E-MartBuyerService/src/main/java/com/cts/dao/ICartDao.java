package com.cts.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.ShoppingCartEntity;


@Repository
public interface ICartDao extends JpaRepository<ShoppingCartEntity, Integer> {
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM cart WHERE buyer_buyer_id = :buyerId",nativeQuery = true)
	public void emptyCart(@Param("buyerId")Integer buyerId);

	@Query(value = "SELECT * FROM cart c WHERE c.buyer_buyer_id = :buyerId",nativeQuery = true)
	public List<ShoppingCartEntity> getAllCartItems(@Param("buyerId")Integer buyerId);

	

	

}
