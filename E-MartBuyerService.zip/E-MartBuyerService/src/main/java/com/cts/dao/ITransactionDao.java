package com.cts.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.TransactionEntity;



public interface ITransactionDao extends JpaRepository<TransactionEntity, Integer>{

}
