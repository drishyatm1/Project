import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart'
import { Buyer } from './Buyer';
import { PurchaseHistory } from './PurchaseHistory';
import { Transaction } from './Transaction';
import { ApiResponse } from './api.response';
@Injectable({
  providedIn: 'root'
})
export class SearchItemServiceService {
  
  
  constructor(private http:HttpClient) { }


  //private baseUrl="http://localhost:8000/token/generate-token";
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8000/' + 'token/generate-token', loginPayload);
  }
  
  private baseUrl1="http://localhost:8085/item/getMatchingItem";
  getItemByName(itemNamePattern : String) : Observable<any> {
    return this.http.get(`${this.baseUrl1}/${itemNamePattern}`);
  }
 
  private baseUrl2="http://localhost:8000/cart/addToCart/ById";
  addToCart(cart: ShoppingCart,bid:String) : Observable<any> {
    return this.http.post(`${this.baseUrl2}/${bid}`,cart);
  }


  private baseUrl3="http://localhost:8000/cart/getCartItem/ByBuyerId";
  displayCartItems(bid:String) : Observable<any>{
    return this.http.get(`${this.baseUrl3}/${bid}`);
  }


  private baseUrl4="http://localhost:8000/buyer/addBuyer";
  createbuyer(buyer: Buyer) :  Observable<any> {
    return this.http.post(`${this.baseUrl4}`,buyer);
  }

  private baseUrl5="http://localhost:8000/cart/updatecart";
  updateCart(id:number,cart: ShoppingCart) :  Observable<any>{
    console.log(cart);
    return this.http.post(`${this.baseUrl5}/${id}`,cart);
    
  }
  
  private baseUrl6="http://localhost:8000/cart/deleteById";
  deleteCartItem(id: any) :  Observable<any>{
    return this.http.delete(`${this.baseUrl6}/${id}`);
  }

  private baseUrl7="http://localhost:8000/cart/checkout";
  checkOut(transaction: Transaction,bid:String) {
    return this.http.post(`${this.baseUrl7}/${bid}`,transaction);
  }
   
 
  
}

