import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchItemComponent } from './search-item/search-item.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { BuyerAfterLoginComponent } from './buyer-after-login/buyer-after-login.component';
import { TransactionComponent } from './transaction/transaction.component';
import { LogoutComponent } from './logout/logout.component';
import { TransactionSuccessComponent } from './transaction-success/transaction-success.component';



const routes: Routes = [
  { path:'SearchItem', component: SearchItemComponent},
  { path:'DisplayCart', component: DisplayCartComponent},
  { path:'SignUp',component: SignupComponent},
  { path:'SignIn', component: SigninComponent},
  { path:'Buyer', component:BuyerAfterLoginComponent },
  { path:'Transaction', component:TransactionComponent },
  { path:'logout', component:LogoutComponent },
  { path:'success', component:TransactionSuccessComponent }
  
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
