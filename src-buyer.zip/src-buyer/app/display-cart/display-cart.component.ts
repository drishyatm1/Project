import { Component, OnInit } from '@angular/core';
import { ShoppingCart } from '../ShoppingCart';
import { SearchItemServiceService } from '../search-item-service.service';
// import { Transaction } from '../Transaction';
// import { PurchaseHistory } from '../PurchaseHistory';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {

  // transaction: Transaction= new Transaction();
  // pHistory: PurchaseHistory=new PurchaseHistory();
  displayCart: ShoppingCart[];
  cart: ShoppingCart= new ShoppingCart();
 
  count: number;
  initialPrice:number;
  bid:String=localStorage.getItem("id");
  constructor(private display :SearchItemServiceService) { }

  ngOnInit(): void {
    this.display.displayCartItems(this.bid)
    .subscribe(displayCart => this.displayCart= displayCart)
    console.log(this.displayCart)
  }
  decrease(cart:ShoppingCart,id: number){
    if(cart.quantity==1){
      this.initialPrice=cart.price;
    }
    cart.quantity -=1;
    if(cart.quantity>=1){
      cart.price= cart.quantity * this.initialPrice;
    this.display.updateCart(id,cart).subscribe(cart => this.cart=cart);
    console.log(cart.quantity);
    }
  }

  increase(cart:ShoppingCart,id: number){
    console.log(cart.quantity)
    console.log(cart);
    if(cart.quantity==1){
      this.initialPrice=cart.price;
    }
    cart.quantity +=1;
    if(cart.quantity>=1){
      cart.price= cart.quantity * this.initialPrice;
    this.display.updateCart(id,cart).subscribe(cart => this.cart=cart);
    console.log(cart.quantity);
    console.log(cart.price);
    }
  }

  delete(id: number){

    this.display.deleteCartItem(id)
    .subscribe(()=>console.log("deleted"));
  }

  //  checkOut(cart){
  //   console.log(cart);
  //   this.display.checkOut(cart,this.transaction,this.pHistory)
  //   .subscribe(cart => {alert("You have ordered all items")});
  //  }
}
