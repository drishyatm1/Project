import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchItemComponent } from './search-item/search-item.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';



const routes: Routes = [
  { path:'SearchItem', component: SearchItemComponent},
  { path:'DisplayCart', component: DisplayCartComponent}
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
