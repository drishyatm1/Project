import { Component, OnInit } from '@angular/core';
import { ShoppingCart } from '../ShoppingCart';
import { SearchItemServiceService } from '../search-item-service.service';

@Component({
  selector: 'app-display-cart',
  templateUrl: './display-cart.component.html',
  styleUrls: ['./display-cart.component.css']
})
export class DisplayCartComponent implements OnInit {


  displayCart: ShoppingCart[];

  constructor(private display :SearchItemServiceService) { }

  ngOnInit(): void {
    this.display.displayCartItems()
    .subscribe(displayCart => this.displayCart= displayCart)
    console.log(this.displayCart)
  }

}
