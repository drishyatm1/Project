import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart'
@Injectable({
  providedIn: 'root'
})
export class SearchItemServiceService {
  
  
  
  private baseUrl1="http://localhost:8085/item/getMatchingItem";
  getItemByName(itemNamePattern : String) : Observable<any> {
    return this.http.get(`${this.baseUrl1}/${itemNamePattern}`);
  }
 
  private baseUrl2="http://localhost:8080/cart";
  addToCart(cart: object) : Observable<any> {
    return this.http.post(`${this.baseUrl2}/`+`/addToCart/ById/2`,cart);
  }


  private baseUrl3="http://localhost:8080/cart/getAll/CartItem";
  displayCartItems() : Observable<any>{
    return this.http.get(`${this.baseUrl3}`);
  }
 
  constructor(private http:HttpClient) { }
}
