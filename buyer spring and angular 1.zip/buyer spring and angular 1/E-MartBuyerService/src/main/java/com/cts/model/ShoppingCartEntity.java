package com.cts.model;

import java.util.List;

import javax.persistence.*;

import org.springframework.beans.factory.annotation.Autowired;


@Entity
@Table(name="cart")
public class ShoppingCartEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int cartId;
	private float price;
	private int quantity;
	/////
	private int itemId;
	
	
	
	  
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public List<ItemsEntity> getItemsEntity() {
		return itemsEntity;
	}
	public void setItemsEntity(List<ItemsEntity> itemsEntity) {
		this.itemsEntity = itemsEntity;
	}
	public BuyerEntity getBuyer() {
		return buyer;
	}
	public void setBuyer(BuyerEntity buyer) {
		this.buyer = buyer;
	}
	@OneToMany//(cascade=CascadeType.ALL,mappedBy="shoppingCart")
	  private List<ItemsEntity> itemsEntity;
	    
	  @ManyToOne
	  private BuyerEntity buyer;
	 
	 
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	
	public ShoppingCartEntity() {
		
		// TODO Auto-generated constructor stub
	}
	
	
	public ShoppingCartEntity(int cartId, float price, int quantity, int itemId, List<ItemsEntity> itemsEntity,
			BuyerEntity buyer) {
		super();
		this.cartId = cartId;
		this.price = price;
		this.quantity = quantity;
		this.itemId = itemId;
		this.itemsEntity = itemsEntity;
		this.buyer = buyer;
	}
	@Override
	public String toString() {
		return "ShoppingCartEntity [cartId=" + cartId + ", price=" + price + ", quantity=" + quantity + ", itemId="
				+ itemId + ", itemsEntity=" + itemsEntity + ", buyer=" + buyer + "]";
	}
	
	
	
	
	
	
	
	

}
