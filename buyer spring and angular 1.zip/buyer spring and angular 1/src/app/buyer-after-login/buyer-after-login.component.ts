import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-after-login',
  templateUrl: './buyer-after-login.component.html',
  styleUrls: ['./buyer-after-login.component.css']
})
export class BuyerAfterLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
