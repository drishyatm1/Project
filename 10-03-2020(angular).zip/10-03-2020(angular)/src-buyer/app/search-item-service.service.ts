import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart'
import { Buyer } from './Buyer';
import { PurchaseHistory } from './PurchaseHistory';
import { Transaction } from './Transaction';
import { ApiResponse } from './api.response';
@Injectable({
  providedIn: 'root'
})
export class SearchItemServiceService {
  
  
  constructor(private http:HttpClient) { }


  //private baseUrl="http://localhost:8000/token/generate-token";
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8000/' + 'token/generate-token', loginPayload);
  }
  
  private baseUrl1="http://localhost:8085/item/getMatchingItem";
  getItemByName(itemNamePattern : String) : Observable<any> {
    return this.http.get(`${this.baseUrl1}/${itemNamePattern}`);
  }
 
  private baseUrl2="http://localhost:8000/cart/addToCart/ById/3";
  addToCart(cart: ShoppingCart) : Observable<any> {
    return this.http.post(`${this.baseUrl2}/`,cart);
  }


  private baseUrl3="http://localhost:8000/cart/getCartItem/ByBuyerId/3";
  displayCartItems() : Observable<any>{
    return this.http.get(`${this.baseUrl3}`);
  }


  private baseUrl4="http://localhost:8000/buyer/addBuyer";
  createbuyer(buyer: Buyer) :  Observable<any> {
    return this.http.post(`${this.baseUrl4}`,buyer);
  }

  private baseUrl5="http://localhost:8000/cart/updatecart";
  updateCart(id:number,cart: ShoppingCart) :  Observable<any>{
    console.log(cart);
    return this.http.post(`${this.baseUrl5}/${id}`,cart);
    
  }
  
  private baseUrl6="http://localhost:8000/cart/deleteById";
  deleteCartItem(id: any) :  Observable<any>{
    return this.http.delete(`${this.baseUrl6}/${id}`);
  }

  private baseUrl7="http://localhost:8000/cart/checkout/3";
  checkOut(transaction: Transaction) {
    return this.http.post(`${this.baseUrl7}`,transaction);
  }
   
 
  
}

