export class ShoppingCart{
    cartId : number;
    price : number;
    quantity : number;

    itemId:number;

}