import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-seller-view-item',
  templateUrl: './seller-view-item.component.html',
  styleUrls: ['./seller-view-item.component.css']
})
export class SellerViewItemComponent implements OnInit {

  constructor(private viewItem:SellerServiceService) { }
  
  displayItem:Item[];
  item: Item=new Item();
  ngOnInit(): void {
    this.viewItem.viewItem()
    .subscribe(displayItem => this.displayItem= displayItem)
    console.log(this.displayItem)
  }

  deleteItem(sellerId:number,itemId:number){
    console.log(sellerId);
    this.viewItem.deleteItem(sellerId,itemId)
    .subscribe(()=>console.log("deleted"));

  }

  updateItem(sellerId:number,itemId:number){
    console.log(this.item);
    console.log(itemId);
    this.viewItem.updateItem(this.item)
    .subscribe(item => this.item=item);
    console.log(this.item);
  }


}
