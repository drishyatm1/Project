export class  Transaction{
    transactionId: number;
    transactionType: String;
    buyerId:number;
}