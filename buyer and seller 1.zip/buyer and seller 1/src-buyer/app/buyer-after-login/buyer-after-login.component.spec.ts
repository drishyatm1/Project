import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyerAfterLoginComponent } from './buyer-after-login.component';

describe('BuyerAfterLoginComponent', () => {
  let component: BuyerAfterLoginComponent;
  let fixture: ComponentFixture<BuyerAfterLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyerAfterLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyerAfterLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
