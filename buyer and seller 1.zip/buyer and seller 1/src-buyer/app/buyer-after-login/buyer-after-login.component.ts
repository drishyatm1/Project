import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-buyer-after-login',
  templateUrl: './buyer-after-login.component.html',
  styleUrls: ['./buyer-after-login.component.css']
})
export class BuyerAfterLoginComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  toSearchItem(){

    this.router.navigate(['SearchItem']);
  }
  toListItem(){

    this.router.navigate(['DisplayCart']);

  }

}
