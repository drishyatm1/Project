package com.cts.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.PurchaseHistoryEntity;



public interface IPurchaseHistoryDao extends JpaRepository<PurchaseHistoryEntity, Integer> {

}
