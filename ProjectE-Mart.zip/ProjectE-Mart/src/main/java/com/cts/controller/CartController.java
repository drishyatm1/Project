package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.BuyerEntity;
import com.cts.model.ShoppingCartEntity;
import com.cts.service.ICartService;


@RestController
public class CartController {
	@Autowired
	private ICartService cartService;
	
	@GetMapping("/getAll/CartItem")
	public List<ShoppingCartEntity> getAll(){
		
		return cartService.getAllCart();
	}
	
	
	//working only with cart id******
	@GetMapping("getCartItem/ById/{bid}")
	public ShoppingCartEntity getbyId(@PathVariable("bId") int bId) {
		
		Optional<ShoppingCartEntity> c=cartService.getCartById(bId);
		ShoppingCartEntity pObj=null;
		if(c.isPresent()){
		 pObj=c.get();	
		}		
		return pObj;
	}

	
	@PostMapping("/addToCart")
	public ShoppingCartEntity addPerson(@RequestBody ShoppingCartEntity cItem) {
		
		return cartService.addCart(cItem);
	}
	
	
	//only with cart id
	@DeleteMapping("deleteById/{bid}")
	public void deleteById(@PathVariable("bid") Integer bId) {
		
		cartService.deleteById(bId);
		
	}
	
	@DeleteMapping("/deleteAllCart")
	public void deleteAllCart() {
		
		cartService.deleteAllCart();
		
	}
}
