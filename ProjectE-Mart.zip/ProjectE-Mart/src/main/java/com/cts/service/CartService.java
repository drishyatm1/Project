package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ICartDao;
import com.cts.model.ShoppingCartEntity;

@Service
public class CartService implements ICartService {
	
	@Autowired
	private ICartDao cartDao;

	@Override
	public List<ShoppingCartEntity> getAllCart() {
		
		return cartDao.findAll();
	}

	@Override
	public Optional<ShoppingCartEntity> getCartById(int bid) {
		// TODO Auto-generated method stub
		return cartDao.findById(bid);
	}

	@Override
	public ShoppingCartEntity addCart(ShoppingCartEntity cItem) {
		 			
			return cartDao.save(cItem);
			
			
	}

	@Override
	public void deleteById(Integer bId) {
		Optional<ShoppingCartEntity> person = cartDao.findById(bId);
		
		if(person.isPresent()) {
			cartDao.deleteById(bId);
		}
		
	}

	@Override
	public void deleteAllCart() {
		cartDao.deleteAll();
		
	}
		
	

	
}
