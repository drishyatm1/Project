package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class TransactionEntity {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	public int Id;
	public int userId;
	public int sellerId;
	public String transactionType;
	
	public String remarks;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public TransactionEntity(int id, int userId, int sellerId, String transactionType, String remarks) {
		super();
		Id = id;
		this.userId = userId;
		this.sellerId = sellerId;
		this.transactionType = transactionType;
		this.remarks = remarks;
	}

	public TransactionEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "TransactionEntity [Id=" + Id + ", userId=" + userId + ", sellerId=" + sellerId + ", transactionType="
				+ transactionType + ", remarks=" + remarks + "]";
	}


	
}
