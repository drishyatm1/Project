import { Component, OnInit, Input } from '@angular/core';
import { SellerServiceService } from './seller-service.service';
import { Item } from './item';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SellerView';

 itemName: String;
 storeItem: Item[];


  constructor(private dataservice:  SellerServiceService){

  }

  ngOnInit(){
    this.itemName="";
  }
    

  private searchItem(){
    console.log(this.itemName);
    this.dataservice.searchitems(this.itemName)
    .subscribe(storeItem =>this.storeItem=storeItem);
  }
  onSubmit(){
    this.searchItem();
  }



}
