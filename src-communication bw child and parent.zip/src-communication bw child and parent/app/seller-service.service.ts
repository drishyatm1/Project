import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
 
private baseUrl='http://localhost:8085/getMatchingItem';


constructor(private http: HttpClient) { }

  searchitems(itemName: String) :Observable<any>{
  
    
    return this.http.get(`${this.baseUrl}/${itemName}`);
  

   
  }
}
