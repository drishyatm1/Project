package com.cts.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.ItemsEntity;

public interface IItemDao extends JpaRepository<ItemsEntity, Integer> {

}
