import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { NgForm } from '@angular/forms';
import { SellerServiceService } from '../seller-service.service';
import { Router } from '@angular/router';
import { Seller } from '../Seller';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor(private sellerservice:SellerServiceService,private router: Router) { }

  item: Item=new Item();
  seller:Seller=new Seller();
  ngOnInit(): void {
  }


  onSubmit(form:NgForm){
    console.log(this.item);
    this.sellerservice.addItem(this.item,this.item.sellerId)
    .subscribe(item=>{alert("Product added successfully .")})
    console.log(this.item);
    this.router.navigate(['addItem']);
  

  }
}
