import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from './signin/signin.component';

import { SellerSignUpComponent } from './seller-sign-up/seller-sign-up.component';
import { AddItemComponent } from './add-item/add-item.component';




const routes: Routes = [
  
  { path:'signin', component: SigninComponent},
  { path:'sellersignup', component: SellerSignUpComponent},
  { path:'addItem', component: AddItemComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
